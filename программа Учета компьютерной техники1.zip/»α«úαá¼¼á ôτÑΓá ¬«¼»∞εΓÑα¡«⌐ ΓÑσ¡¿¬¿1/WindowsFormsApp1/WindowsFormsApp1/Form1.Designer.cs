﻿
namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.техникаBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.companyDBzDataSet3 = new WindowsFormsApp1.CompanyDBzDataSet3();
            this.техникаTableAdapter = new WindowsFormsApp1.CompanyDBzDataSet3TableAdapters.техникаTableAdapter();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.кодDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.техникаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.допинформацияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.принадлежитDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.техникаBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.companyDBzDataSet4 = new WindowsFormsApp1.CompanyDBzDataSet4();
            this.companyDBzDataSet4BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.техникаTableAdapter1 = new WindowsFormsApp1.CompanyDBzDataSet4TableAdapters.техникаTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.техникаBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.companyDBzDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.техникаBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.companyDBzDataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.companyDBzDataSet4BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 272);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(187, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Укажите код техники для удаления";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(403, 226);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(241, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Укажите код техники для замены сотрудника";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(463, 285);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(151, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Укажите нового сотрудника";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 301);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(187, 20);
            this.textBox1.TabIndex = 4;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(406, 242);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(238, 20);
            this.textBox2.TabIndex = 5;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(406, 301);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(238, 20);
            this.textBox3.TabIndex = 6;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 327);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(187, 80);
            this.button1.TabIndex = 7;
            this.button1.Text = "Удалять технику";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(297, 327);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(458, 81);
            this.button2.TabIndex = 8;
            this.button2.Text = "изменить сотрудника за кем привязана техника";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(484, 12);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(271, 85);
            this.button3.TabIndex = 9;
            this.button3.Text = "добавить технику";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(484, 106);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(271, 56);
            this.button4.TabIndex = 10;
            this.button4.Text = "Обновить ";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // техникаBindingSource
            // 
            this.техникаBindingSource.DataMember = "техника";
            this.техникаBindingSource.DataSource = this.companyDBzDataSet3;
            // 
            // companyDBzDataSet3
            // 
            this.companyDBzDataSet3.DataSetName = "CompanyDBzDataSet3";
            this.companyDBzDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // техникаTableAdapter
            // 
            this.техникаTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодDataGridViewTextBoxColumn,
            this.техникаDataGridViewTextBoxColumn,
            this.допинформацияDataGridViewTextBoxColumn,
            this.принадлежитDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.техникаBindingSource1;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(452, 195);
            this.dataGridView1.TabIndex = 11;
            // 
            // кодDataGridViewTextBoxColumn
            // 
            this.кодDataGridViewTextBoxColumn.DataPropertyName = "Код";
            this.кодDataGridViewTextBoxColumn.HeaderText = "Код";
            this.кодDataGridViewTextBoxColumn.Name = "кодDataGridViewTextBoxColumn";
            // 
            // техникаDataGridViewTextBoxColumn
            // 
            this.техникаDataGridViewTextBoxColumn.DataPropertyName = "техника";
            this.техникаDataGridViewTextBoxColumn.HeaderText = "техника";
            this.техникаDataGridViewTextBoxColumn.Name = "техникаDataGridViewTextBoxColumn";
            // 
            // допинформацияDataGridViewTextBoxColumn
            // 
            this.допинформацияDataGridViewTextBoxColumn.DataPropertyName = "Допинформация";
            this.допинформацияDataGridViewTextBoxColumn.HeaderText = "Допинформация";
            this.допинформацияDataGridViewTextBoxColumn.Name = "допинформацияDataGridViewTextBoxColumn";
            // 
            // принадлежитDataGridViewTextBoxColumn
            // 
            this.принадлежитDataGridViewTextBoxColumn.DataPropertyName = "принадлежит";
            this.принадлежитDataGridViewTextBoxColumn.HeaderText = "принадлежит";
            this.принадлежитDataGridViewTextBoxColumn.Name = "принадлежитDataGridViewTextBoxColumn";
            // 
            // техникаBindingSource1
            // 
            this.техникаBindingSource1.DataMember = "техника";
            this.техникаBindingSource1.DataSource = this.companyDBzDataSet4;
            // 
            // companyDBzDataSet4
            // 
            this.companyDBzDataSet4.DataSetName = "CompanyDBzDataSet4";
            this.companyDBzDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // companyDBzDataSet4BindingSource
            // 
            this.companyDBzDataSet4BindingSource.DataSource = this.companyDBzDataSet4;
            this.companyDBzDataSet4BindingSource.Position = 0;
            // 
            // техникаTableAdapter1
            // 
            this.техникаTableAdapter1.ClearBeforeFill = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(767, 504);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Учет компьютерной техники";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.техникаBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.companyDBzDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.техникаBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.companyDBzDataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.companyDBzDataSet4BindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private CompanyDBzDataSet3 companyDBzDataSet3;
        private System.Windows.Forms.BindingSource техникаBindingSource;
        private CompanyDBzDataSet3TableAdapters.техникаTableAdapter техникаTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource companyDBzDataSet4BindingSource;
        private CompanyDBzDataSet4 companyDBzDataSet4;
        private System.Windows.Forms.BindingSource техникаBindingSource1;
        private CompanyDBzDataSet4TableAdapters.техникаTableAdapter техникаTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn техникаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn допинформацияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn принадлежитDataGridViewTextBoxColumn;
    }
}

